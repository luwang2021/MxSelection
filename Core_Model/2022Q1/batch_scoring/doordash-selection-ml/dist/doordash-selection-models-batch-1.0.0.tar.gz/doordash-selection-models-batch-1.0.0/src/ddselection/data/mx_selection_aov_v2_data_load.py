from ddselection.data.mx_selection_aov_caviar_v2_training_data_query import *
from ddselection.data.mx_selection_aov_caviar_v2_prediction_data_query import *
from ddselection.data.utils import *
from ddselection.config_aov_v2 import *


logging.basicConfig(level=logging.INFO)
logging.getLogger("py4j").setLevel(logging.ERROR)
logger = logging.getLogger(__name__)


def load_mxselection_aov_training_data_v2(schema, role, user, password):
    """Load training data for selection aov v2 models

    Args:
        schema                    (str): databricks schema
        role                      (str): user role in snowflake
        user                      (str): databricks user credential
        password                  (str): databricks password credential

    Returns:
        pandas DFs: training data for
                    nn(net new), ac(active np) and da(deactivated) mx

    """
    nn_dataset = Dataset(
        name='nn',
        query=q_aov_training_data_nn_v2,
        date_cols=DATE_SPLIT_COL,
        selected_cols=(
            NN_NUM_COLS + NN_CAT_COLS + PASSTHROUGH_COLS
            + NN_Y_COL
        )
    )


    logger.info('load net new mx data')
    nn_train = DataLoader(nn_dataset, schema, role, user, password).load_pd()
    return nn_train


def load_mxselection_aov_prediction_data_v2(
    pred_date,
    schema,
    role,
    user,
    password
):
    """Load prediction features for selection aov v2 models

    Args:
        pred_date                 (str): prediction date
        schema                    (str): databricks schema
        role                      (str): user role in snowflake
        user                      (str): databricks user credential
        password                  (str): databricks password credential

    Returns:
        pandas DFs: prediction features for
                    nn(net new), ac(active np) and da(deactivated) mx

    """
    nn_pred_features_dataset = Dataset(
        name='nn',
        query=query_nn_pred_features_aov_v2.format(test_date=pred_date),
        date_cols=None,
        selected_cols=(
            NN_NUM_COLS + NN_CAT_COLS + PASSTHROUGH_COLS
        )
    )
    logger.info('load net new mx data for prediction')
    nn_pred_features = DataLoader(
        nn_pred_features_dataset, schema, role, user, password
    ).load_pd()
    return nn_pred_features
